#!/bin/sh
vim -u NONE -i NONE --not-a-term -e -s -N -X -S macros/generate-ftplugins.vim -c quit
