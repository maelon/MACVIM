This is a [VIM][] plugin for using [JSON][] in a way that I like. It is a fork of [vim-scripts/vim-json-bundle][], which is a fork of [leshill/vim-json][].

Packaged for usage with [pathogen][].

[VIM]: https://en.wikipedia.org/wiki/Vim_(text_editor)
[JSON]: https://en.wikipedia.org/wiki/JSON
[vim-scripts/vim-json-bundle]: https://github.com/vim-scripts/vim-json-bundle
[leshill/vim-json]: https://github.com/leshill/vim-json
[pathogen]: https://github.com/tpope/vim-pathogen
